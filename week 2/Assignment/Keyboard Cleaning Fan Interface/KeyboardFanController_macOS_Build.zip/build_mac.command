#!/bin/bash
set -e

cd "$(dirname "$0")"

echo "=========================================="
echo "Keyboard Fan Controller - macOS Builder"
echo "=========================================="
echo

ARCH="$(uname -m)"
echo "Mac architecture: $ARCH"
echo

if ! command -v brew >/dev/null 2>&1; then
    echo "ERROR: Homebrew is not installed."
    echo
    echo "Install Homebrew first from:"
    echo "https://brew.sh"
    echo
    echo "Then run this file again."
    exit 1
fi

if ! command -v python3 >/dev/null 2>&1; then
    echo "Python 3 was not found."
    echo "Installing Python with Homebrew..."
    brew install python
fi

echo "[1/5] Installing HIDAPI..."
brew install hidapi || brew upgrade hidapi || true

echo
echo "[2/5] Creating local Python environment..."
python3 -m venv .venv

source .venv/bin/activate

python -m pip install --upgrade pip

echo
echo "[3/5] Installing Python dependencies..."
python -m pip install -r requirements-mac.txt

HIDAPI_PREFIX="$(brew --prefix hidapi)"
HIDAPI_LIB="$HIDAPI_PREFIX/lib/libhidapi.dylib"

if [ ! -f "$HIDAPI_LIB" ]; then
    echo
    echo "ERROR: Could not find:"
    echo "$HIDAPI_LIB"
    echo
    echo "Check the Homebrew HIDAPI installation."
    exit 1
fi

echo
echo "HIDAPI library:"
echo "$HIDAPI_LIB"

echo
echo "[4/5] Building macOS executable..."

python -m PyInstaller \
    --noconfirm \
    --clean \
    --onefile \
    --console \
    --name KeyboardFanController-mac \
    --add-binary "$HIDAPI_LIB:." \
    controller_bridge.py

echo
echo "[5/5] Done."
echo
echo "Built file:"
echo "$(pwd)/dist/KeyboardFanController-mac"
echo
echo "IMPORTANT:"
echo "This build is architecture-specific: $ARCH"
echo "Apple Silicon builds should be used on Apple Silicon Macs."
echo "Intel builds should be used on Intel Macs."
echo
echo "For the first test, connect DualSense by USB."
echo
