#!/bin/bash
set -e

cd "$(dirname "$0")"

if [ ! -d ".venv" ]; then
    echo "No .venv found."
    echo "Run ./build_mac.command first."
    exit 1
fi

source .venv/bin/activate

python controller_bridge.py
