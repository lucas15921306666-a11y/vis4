import asyncio
import json

import websockets

from pydualsense import (
    pydualsense,
    TriggerModes
)


controller = pydualsense()

print("Connecting to DualSense...")
controller.init()
print("DualSense connected.")


# ============================================================
# FEEDBACK SETTINGS
# ============================================================

RUMBLE_CURVE_EXPONENT = 2.0

TRIGGER_CURVE_EXPONENT = 1.6

TRIGGER_MIN_FORCE = 25

TRIGGER_MAX_FORCE = 220


current_speed = 0

last_trigger_force = -1


# ============================================================
# RUMBLE
# ============================================================

def speed_to_motor_strength(speed):

    speed = max(
        0,
        min(
            100,
            int(speed)
        )
    )

    normalized = speed / 100.0

    curved = (
        normalized
        ** RUMBLE_CURVE_EXPONENT
    )

    return round(
        curved * 255
    )


# ============================================================
# ADAPTIVE TRIGGER
# ============================================================

def speed_to_trigger_force(speed):

    speed = max(
        0,
        min(
            100,
            int(speed)
        )
    )

    if speed <= 0:
        return 0

    normalized = speed / 100.0

    curved = (
        normalized
        ** TRIGGER_CURVE_EXPONENT
    )

    force_range = (
        TRIGGER_MAX_FORCE
        -
        TRIGGER_MIN_FORCE
    )

    force = (
        TRIGGER_MIN_FORCE
        +
        round(
            curved
            *
            force_range
        )
    )

    return max(
        0,
        min(
            255,
            force
        )
    )


def set_rumble(speed):

    strength = (
        speed_to_motor_strength(
            speed
        )
    )

    controller.setLeftMotor(
        strength
    )

    controller.setRightMotor(
        strength
    )

    return strength


def stop_rumble():

    controller.setLeftMotor(
        0
    )

    controller.setRightMotor(
        0
    )


def clear_trigger():

    global last_trigger_force

    controller.triggerR.setMode(
        TriggerModes.Off
    )

    for force_id in range(7):

        controller.triggerR.setForce(
            force_id,
            0
        )

    last_trigger_force = 0


def set_trigger_resistance(speed):

    global last_trigger_force

    force = (
        speed_to_trigger_force(
            speed
        )
    )

    if force <= 0:

        if last_trigger_force != 0:
            clear_trigger()

        return 0

    if force == last_trigger_force:
        return force

    controller.triggerR.setMode(
        TriggerModes.Rigid
    )

    for force_id in range(7):

        controller.triggerR.setForce(
            force_id,
            0
        )

    controller.triggerR.setForce(
        1,
        force
    )

    last_trigger_force = force

    return force


def set_fan_feedback(speed):

    global current_speed

    speed = max(
        0,
        min(
            100,
            int(speed)
        )
    )

    current_speed = speed

    rumble_strength = (
        set_rumble(
            speed
        )
    )

    trigger_force = (
        set_trigger_resistance(
            speed
        )
    )

    print(
        f"Fan Speed: {speed:3d}"
        f" | Rumble: {rumble_strength:3d}"
        f" | R2 Force: {trigger_force:3d}",
        end="\r"
    )


def stop_all_feedback():

    global current_speed

    current_speed = 0

    stop_rumble()

    clear_trigger()


# ============================================================
# WEBSOCKET
# ============================================================

async def handle_client(websocket):

    print()
    print("Browser connected.")

    try:

        async for message in websocket:

            try:

                data = json.loads(
                    message
                )

            except json.JSONDecodeError:

                print()
                print(
                    "Invalid JSON:",
                    message
                )

                continue

            message_type = (
                data.get(
                    "type"
                )
            )

            if (
                message_type
                ==
                "fanSpeed"
            ):

                speed = (
                    data.get(
                        "value",
                        0
                    )
                )

                try:

                    speed = int(
                        speed
                    )

                except (
                    TypeError,
                    ValueError
                ):

                    speed = 0

                set_fan_feedback(
                    speed
                )

            elif (
                message_type
                ==
                "stop"
            ):

                stop_all_feedback()

    except websockets.ConnectionClosed:

        pass

    finally:

        stop_all_feedback()

        print()
        print(
            "Browser disconnected."
        )


async def main():

    print(
        "Starting WebSocket bridge..."
    )

    print()
    print(
        "Feedback:"
    )
    print(
        "- Controller rumble"
    )
    print(
        "- R2 adaptive resistance"
    )
    print()

    async with websockets.serve(

        handle_client,

        "127.0.0.1",

        8765

    ):

        print(
            "Bridge ready:"
        )

        print(
            "ws://127.0.0.1:8765"
        )

        print()
        print(
            "Open the webpage and press R2."
        )
        print(
            "Press Control+C to stop."
        )
        print()

        await asyncio.Future()


try:

    asyncio.run(
        main()
    )

except KeyboardInterrupt:

    print()
    print(
        "Stopping bridge..."
    )

finally:

    stop_all_feedback()

    controller.close()

    print(
        "DualSense disconnected."
    )
